#!/bin/bash
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
ROUTER_IP="${1:-}"
SSH_KEY="${2:-}"

if [[ -z "$ROUTER_IP" ]]; then
  read -r -p "IP адрес AX6000: " ROUTER_IP
fi
if [[ -z "$SSH_KEY" ]]; then
  read -r -p "Абсолютный путь к root SSH-ключу для этого роутера: " SSH_KEY
fi
if [[ ! -f "$SSH_KEY" ]]; then
  echo "SSH key file not found: $SSH_KEY" >&2
  exit 2
fi

(cd "$BUNDLE_DIR/payload/tree" && shasum -a 256 -c SHA256SUMS)
(cd "$BUNDLE_DIR/payload/sources" && shasum -a 256 -c SHA256SUMS)

ssh_opts=(-i "$SSH_KEY" -o BatchMode=yes -o ConnectTimeout=8 -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new)
echo "Проверяю root SSH на $ROUTER_IP..."
ssh "${ssh_opts[@]}" "root@$ROUTER_IP" 'test "$(id -u)" = 0'
ssh "${ssh_opts[@]}" "root@$ROUTER_IP" 'mkdir -p /tmp/ax6000-luci-doh-bundle'
scp -O -r -i "$SSH_KEY" -o BatchMode=yes -o ConnectTimeout=8 -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new \
  "$BUNDLE_DIR/payload" "root@$ROUTER_IP:/tmp/ax6000-luci-doh-bundle/"
ssh "${ssh_opts[@]}" "root@$ROUTER_IP" 'sh /tmp/ax6000-luci-doh-bundle/payload/install_remote.sh'

echo "Установка завершена. LuCI: http://$ROUTER_IP/"
