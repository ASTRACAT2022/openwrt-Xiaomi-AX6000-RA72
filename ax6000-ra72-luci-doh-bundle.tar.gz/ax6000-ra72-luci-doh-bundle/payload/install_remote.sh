#!/bin/sh
set -eu

PAYLOAD=/tmp/ax6000-luci-doh-bundle/payload
BASE=/data/ax6000-clean-mod

fail() {
    echo "Install stopped: $*" >&2
    exit 1
}

[ "$(id -u)" = 0 ] || fail "run this script as root"
[ -d "$PAYLOAD/tree/overlay" ] || fail "payload tree is missing"

. /etc/openwrt_release
[ "$(uname -m)" = "aarch64" ] || fail "CPU architecture is not aarch64"
[ "$(uname -r)" = "4.4.60" ] || fail "kernel version is not 4.4.60"
[ "$DISTRIB_RELEASE" = "18.06-SNAPSHOT" ] || fail "firmware release is not 18.06-SNAPSHOT"
[ "$DISTRIB_TARGET" = "ipq/ipq50xx_64" ] || fail "firmware target is not ipq/ipq50xx_64"
[ "$DISTRIB_ARCH" = "aarch64_cortex-a53" ] || fail "package architecture does not match"
[ "$(cat /tmp/sysinfo/board_name 2>/dev/null)" = "ap-mp03.1" ] || fail "board is not ap-mp03.1"

FREE_KB=$(df -k /data | awk 'END { print $4 }')
[ "${FREE_KB:-0}" -ge 8000 ] || fail "/data needs at least 8 MiB free"

mkdir -p "$BASE/rollback"
for name in system firewall dhcp luci; do
    if [ ! -s "$BASE/rollback/$name.original" ]; then
        [ -s "/etc/config/$name" ] || fail "missing /etc/config/$name"
        cp -p "/etc/config/$name" "$BASE/rollback/$name.original"
        chmod 600 "$BASE/rollback/$name.original"
    fi
done
if [ ! -s /data/ax6000-luci-stock.bak ]; then
    cp -p /etc/config/luci /data/ax6000-luci-stock.bak
    chmod 600 /data/ax6000-luci-stock.bak
fi

EXISTING_INCLUDE=$(uci -q get firewall.openwrt_luci.path || true)
if [ -n "$EXISTING_INCLUDE" ] && [ "$EXISTING_INCLUDE" != "$BASE/boot_openwrt.sh" ]; then
    fail "firewall.openwrt_luci is already used by another script"
fi
if [ -e /etc/config/https-dns-proxy ] && [ "$(readlink /etc/config/https-dns-proxy 2>/dev/null || true)" != "$BASE/doh/https-dns-proxy.config" ]; then
    fail "/etc/config/https-dns-proxy already exists; inspect it before replacing"
fi
if [ -e /etc/init.d/https-dns-proxy ] && [ "$(readlink /etc/init.d/https-dns-proxy 2>/dev/null || true)" != "$BASE/doh/init/https-dns-proxy" ]; then
    fail "/etc/init.d/https-dns-proxy already exists; inspect it before replacing"
fi

cp -a "$PAYLOAD/tree/." "$BASE/"
chmod 755 "$BASE/boot_openwrt.sh" "$BASE/launch_luci_main.sh" \
    "$BASE/rollback_stock_ui.sh" "$BASE/doh/start_doh.sh" \
    "$BASE/doh/init/https-dns-proxy" "$BASE/doh/bin/https-dns-proxy"
ln -sf "$BASE/doh/https-dns-proxy.config" /etc/config/https-dns-proxy
ln -sf "$BASE/doh/init/https-dns-proxy" /etc/init.d/https-dns-proxy

uci set system.@system[0].hostname='OpenWrt'
uci commit system
uci set luci.main.lang='ru'
uci set luci.main.mediaurlbase='/luci-static/bootstrap'
uci set luci.main.resourcebase='/luci-static/resources'
uci set luci.themes.Bootstrap='/luci-static/bootstrap'
uci commit luci
uci set firewall.openwrt_luci='include'
uci set firewall.openwrt_luci.type='script'
uci set firewall.openwrt_luci.path="$BASE/boot_openwrt.sh"
uci set firewall.openwrt_luci.reload='1'
uci set firewall.openwrt_luci.enabled='1'
uci commit firewall

/etc/init.d/https-dns-proxy enable
if ! /etc/init.d/firewall reload; then
    sh "$BASE/rollback_stock_ui.sh" >/dev/null 2>&1 || true
    fail "firewall reload failed; stock settings were restored"
fi

sleep 3
if ! netstat -lnt 2>/dev/null | grep -q ':80 ' || \
   ! netstat -lnup 2>/dev/null | grep -q '127.0.0.1:5053 ' || \
   ! wget -qO- http://127.0.0.1/luci/ 2>/dev/null | grep -q 'luci_password'; then
    sh "$BASE/rollback_stock_ui.sh" >/dev/null 2>&1 || true
    fail "LuCI or DoH did not start; rollback was run"
fi

echo "AX6000 overlay installed. Open LuCI at http://ROUTER_IP/ using the target router's address."
echo "DoH proxy is listening on 127.0.0.1:5053; DHCP DNS is routed through dnsmasq."
