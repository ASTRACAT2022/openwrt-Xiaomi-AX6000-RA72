#!/bin/sh
BASE=/data/ax6000-clean-mod

killall -9 uhttpd >/dev/null 2>&1
if [ -x /etc/init.d/https-dns-proxy ]; then
    /etc/init.d/https-dns-proxy stop >/dev/null 2>&1
    /etc/init.d/https-dns-proxy disable >/dev/null 2>&1
fi
killall https-dns-proxy >/dev/null 2>&1
umount /usr/share/rpcd/acl.d >/dev/null 2>&1

[ -s "$BASE/rollback/firewall.original" ] && cp -f "$BASE/rollback/firewall.original" /etc/config/firewall
[ -s "$BASE/rollback/system.original" ] && cp -f "$BASE/rollback/system.original" /etc/config/system
[ -s "$BASE/rollback/dhcp.original" ] && cp -f "$BASE/rollback/dhcp.original" /etc/config/dhcp
[ -s /data/ax6000-luci-stock.bak ] && cp -f /data/ax6000-luci-stock.bak /etc/config/luci

/etc/init.d/rpcd restart >/dev/null 2>&1
/etc/init.d/firewall reload >/dev/null 2>&1
/etc/init.d/dnsmasq restart >/dev/null 2>&1

for service in nginx xiaoqiang_sync xq_info_sync_mqtt statisticsservice \
               miwifi-discovery plugincenter plugin_start_script.sh netapi smartcontroller; do
    if [ -x "/etc/init.d/$service" ]; then
        "/etc/init.d/$service" enable >/dev/null 2>&1
        "/etc/init.d/$service" start >/dev/null 2>&1
    fi
done

HOSTNAME=$(uci -q get system.@system[0].hostname)
[ -n "$HOSTNAME" ] && echo "$HOSTNAME" > /proc/sys/kernel/hostname
rm -f /tmp/ax6000-clean-mod-active
echo "Factory UI/config restored; staged files remain under $BASE for review."
