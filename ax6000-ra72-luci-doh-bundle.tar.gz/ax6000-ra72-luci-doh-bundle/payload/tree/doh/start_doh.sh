#!/bin/sh
BASE=/data/ax6000-clean-mod
INIT=/etc/init.d/https-dns-proxy

# LuCI's enable/disable controls this startup link. If disabled, leave DNS as-is.
if [ ! -x /etc/rc.d/S80https-dns-proxy ]; then
    exit 0
fi

if netstat -lnup 2>/dev/null | grep -q '127.0.0.1:5053 '; then
    exit 0
fi
if [ ! -x "$INIT" ] || [ ! -x "$BASE/doh/bin/https-dns-proxy" ]; then
    echo "DoH files missing"
    exit 1
fi
"$INIT" start
for try in 1 2 3 4 5 6 7 8 9 10; do
    netstat -lnup 2>/dev/null | grep -q '127.0.0.1:5053 ' && exit 0
    sleep 1
done
echo "DoH proxy did not bind 127.0.0.1:5053"
exit 1
