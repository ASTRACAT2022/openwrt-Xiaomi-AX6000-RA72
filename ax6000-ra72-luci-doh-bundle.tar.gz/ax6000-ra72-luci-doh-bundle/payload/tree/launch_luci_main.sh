#!/bin/sh
BASE=/data/ax6000-clean-mod
LUA_ROOT=$BASE/overlay/usr/lib/lua
WWW_ROOT=$BASE/overlay/www

export LUA_PATH="$LUA_ROOT/?.lua;$LUA_ROOT/?/init.lua;/usr/lib/lua/?.lua;/usr/lib/lua/?/init.lua"
export LUA_CPATH="$LUA_ROOT/?.so;$LUA_ROOT/?/?.so;/usr/lib/lua/?.so;/usr/lib/lua/?/?.so"
export LD_LIBRARY_PATH="$BASE/overlay/usr/lib:/usr/lib"
export PATH="$BASE/overlay/usr/bin:/usr/sbin:/usr/bin:/sbin:/bin"

exec /usr/sbin/uhttpd -f -p 0.0.0.0:80 -h "$WWW_ROOT" \
    -l /luci -L "$LUA_ROOT/luci/sgi/uhttpd.lua" -u /ubus -t 60
