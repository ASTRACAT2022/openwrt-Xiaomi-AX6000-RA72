#!/bin/sh
BASE=/data/ax6000-clean-mod
ACL_SOURCE=$BASE/merged-acl.d
ACL_TARGET=/usr/share/rpcd/acl.d
LOG=$BASE/boot.log

echo "$(date) applying OpenWrt UI layer" >> "$LOG"

if [ ! -d "$ACL_SOURCE" ]; then
    echo "LuCI ACL overlay is missing" >> "$LOG"
    exit 1
fi
if ! grep -q " $ACL_TARGET " /proc/mounts; then
    if ! mount --bind "$ACL_SOURCE" "$ACL_TARGET"; then
        echo "ACL bind mount failed" >> "$LOG"
        exit 1
    fi
    /etc/init.d/rpcd restart >/dev/null 2>&1
fi

echo OpenWrt > /proc/sys/kernel/hostname

# Stop the Xiaomi web stack and app/cloud agents; keep radio, thermal,
# WAN, QoS, and mesh drivers/services intact.
for service in nginx xiaoqiang_sync xq_info_sync_mqtt statisticsservice \
               miwifi-discovery plugincenter plugin_start_script.sh netapi smartcontroller; do
    if [ -x "/etc/init.d/$service" ]; then
        "/etc/init.d/$service" disable >/dev/null 2>&1
        "/etc/init.d/$service" stop >/dev/null 2>&1
    fi
done
killall -9 nginx fcgi-cgi >/dev/null 2>&1
sleep 1

if ! netstat -lnt 2>/dev/null | grep -q ':80 '; then
    "$BASE/launch_luci_main.sh" > "$BASE/uhttpd-main.log" 2>&1 &
    LUCI_PID=$!
    sleep 2
fi

if ! netstat -lnt 2>/dev/null | grep -q ':80 '; then
    [ -n "$LUCI_PID" ] && kill "$LUCI_PID" >/dev/null 2>&1
    /etc/init.d/nginx enable >/dev/null 2>&1
    /etc/init.d/nginx start >/dev/null 2>&1
    echo "LuCI did not bind port 80; restored nginx" >> "$LOG"
    exit 1
fi

if [ -x "$BASE/doh/start_doh.sh" ]; then
    if ! "$BASE/doh/start_doh.sh" >> "$BASE/doh/start.log" 2>&1; then
        echo "DoH proxy did not start; LuCI remains available" >> "$LOG"
    fi
fi

touch /tmp/ax6000-clean-mod-active
echo "OpenWrt LuCI is listening on port 80" >> "$LOG"
exit 0
