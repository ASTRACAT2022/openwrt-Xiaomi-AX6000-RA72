local open, err = package.loadlib("/data/ax6000-clean-mod/overlay/usr/lib/lua/luci/ip.so", "luaopen_luci_ip")
if not open then error(err) end
return open(...)
