# Sources and checksums

The files in this directory are retained as provenance and for offline reference. The installer deploys the already assembled files in `../tree`; it does not install these `.ipk` archives.

## LuCI overlay source packages

These official OpenWrt 18.06.9 package archives were unpacked and filtered to build the LuCI data overlay. The package index SHA-256 values match the retained files.

Source repository: <https://archive.openwrt.org/releases/18.06.9/packages/aarch64_cortex-a53/luci/>

| Package archive | SHA-256 |
| --- | --- |
| `luci-base_git-20.356.64372-1259bb1-1_aarch64_cortex-a53.ipk` | `83577a96591996d3e1cb7b2b6c9b00049c9e8c4aabade378871a188ad6e7984a` |
| `luci-mod-admin-full_git-20.356.64372-1259bb1-1_aarch64_cortex-a53.ipk` | `8c5a50bce0086f992e7b44fa962e076d00a77f122e55018d2fa15579ced46816` |
| `luci-lib-ip_git-20.356.64372-1259bb1-1_aarch64_cortex-a53.ipk` | `a1e17d74f3ffe063e29f690acddb022bf28747d1519bf0f1b276a3e39d93cbf9` |
| `luci-lib-jsonc_git-20.356.64372-1259bb1-1_aarch64_cortex-a53.ipk` | `043f5afa434ab14e50bd6649686fbe3c5d589aae727597770fed9678e315bd9c` |
| `luci-lib-nixio_git-20.356.64372-1259bb1-1_aarch64_cortex-a53.ipk` | `53e5b93c77053974e507ee7b02e85ead04450409d6a0f7d03e9f36a30808e0f9` |
| `liblucihttp-lua_2019-07-05-a34a17d5-1_aarch64_cortex-a53.ipk` | `105732f24b546b34e560b5fc49c3dee065de3e370d37f12815f699888709f958` |
| `liblucihttp_2019-07-05-a34a17d5-1_aarch64_cortex-a53.ipk` | `ff51020ed9c18b32fcdfa05c8a576e56fec9760ed356c9b4e0967db7d699bbbf` |
| `luci-theme-bootstrap_git-20.356.64372-1259bb1-1_all.ipk` | `9f2ca3cf8a0b35a523472dd0eba0c8d21f444fad6ee00ee4648996a0a59b871a` |
| `luci-i18n-base-ru_git-20.356.64372-1259bb1-1_all.ipk` | `0d1a911bc8cca17cd0b100f51b890fd4450728d68578a3f77abe39c9aa73519e` |

## DNS-over-HTTPS packages

Official OpenWrt 19.07 package archives for `aarch64_cortex-a53`. The installed overlay contains the package files needed by the service and its LuCI page, with small compatibility adjustments for the Xiaomi firmware.

| Package archive | Source | SHA-256 |
| --- | --- | --- |
| `https-dns-proxy.ipk` (2021-09-27-1) | <https://downloads.openwrt.org/releases/packages-19.07/aarch64_cortex-a53/packages/https-dns-proxy_2021-09-27-1_aarch64_cortex-a53.ipk> | `f21a68c3ab493c2787888b5e8789033fcaa2968c1339c3b4f86dda71bafcb16c` |
| `luci-app-https-dns-proxy.ipk` (2021-07-29-1-1) | <https://downloads.openwrt.org/releases/packages-19.07/aarch64_cortex-a53/luci/luci-app-https-dns-proxy_2021-07-29-1-1_all.ipk> | `624d33f5c53dd98720db3af4c829da0b60240571ed1ae1d09bcfcece7320a355` |

## Local bundle manifests

- `SHA256SUMS` covers all regular files in this directory except the manifest itself.
- `../tree/SHA256SUMS` covers all regular files in the installer payload tree except the manifest itself. The Mac installer checks this manifest before connecting to a router.
