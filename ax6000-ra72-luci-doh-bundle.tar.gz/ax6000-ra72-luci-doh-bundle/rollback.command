#!/bin/bash
set -euo pipefail

ROUTER_IP="${1:-}"
SSH_KEY="${2:-}"

if [[ -z "$ROUTER_IP" ]]; then
  read -r -p "IP адрес AX6000: " ROUTER_IP
fi
if [[ -z "$SSH_KEY" ]]; then
  read -r -p "Абсолютный путь к root SSH-ключу для этого роутера: " SSH_KEY
fi
if [[ ! -f "$SSH_KEY" ]]; then
  echo "SSH key file not found: $SSH_KEY" >&2
  exit 2
fi

ssh -i "$SSH_KEY" -o BatchMode=yes -o ConnectTimeout=8 -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new \
  "root@$ROUTER_IP" 'sh /data/ax6000-clean-mod/rollback_stock_ui.sh'
